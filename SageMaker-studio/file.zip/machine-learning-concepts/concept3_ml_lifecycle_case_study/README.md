# Exercise 3: ML Lifecycle Case Study

[App8 Case Study](https://aws.amazon.com/solutions/case-studies/app-8/)

Written response, select 3 of the 11 steps and write a short paragraph explaining how you would go about executing on these parts of the ML Lifecycle.

Exact solutions will vary but should be somewhat related to the answers below.